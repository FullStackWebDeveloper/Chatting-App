module.exports = {
		secret: 'NoHakingJWT'
};